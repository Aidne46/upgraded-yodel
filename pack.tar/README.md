# Codespace Desktop Environment
This repository is a template to create Codespaces with a desktop environment. It is useful when testing applications that require a GUI. It comes with a desktop environment(Fluxbox) which is acessible via noVNC through a forwarded port.
